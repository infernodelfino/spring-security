package com.example.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityLesson02RedoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityLesson02RedoApplication.class, args);
	}

}
