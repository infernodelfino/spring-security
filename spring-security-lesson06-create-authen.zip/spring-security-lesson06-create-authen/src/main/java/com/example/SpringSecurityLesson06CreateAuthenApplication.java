package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityLesson06CreateAuthenApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityLesson06CreateAuthenApplication.class, args);
	}

}
